function mensaje(){
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
    console.log('BOTON PULSADO');
}